#include <stdio.h>

int main(void)
{
    int data = 0x0A0B0C0D;
    unsigned char *pc = (unsigned char *)&data;
    int i;

    for (i = 0; i < (int)sizeof(data); i++)
        printf("*(pc + %d) = %02X\n", i, *(pc + i));

    return 0;
}
