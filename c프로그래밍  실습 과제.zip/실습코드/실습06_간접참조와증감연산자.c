#include <stdio.h>

int main(void)
{
    int i = 10;
    int *pi = &i;

    printf("i = %d, pi = %p\n", i, (void *)pi);

    (*pi)++;
    printf("i = %d, pi = %p\n", i, (void *)pi);

    /* pi++는 포인터 자체를 다음 int 위치로 이동시킨다.
       이동 후에는 pi를 역참조하지 않는다. */
    pi++;
    printf("i = %d, pi = %p\n", i, (void *)pi);

    return 0;
}
