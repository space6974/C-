#include <stdio.h>
#include <stdint.h>

int main(void)
{
    /* 강의자료의 주소값 10000을 정수형 주소로 표현하여
       자료형별 포인터 증가 폭을 안전하게 확인한다. */
    uintptr_t base = 10000;

    printf("char*   : %llu, %llu, %llu\n",
           (unsigned long long)base,
           (unsigned long long)(base + sizeof(char)),
           (unsigned long long)(base + 2 * sizeof(char)));

    printf("int*    : %llu, %llu, %llu\n",
           (unsigned long long)base,
           (unsigned long long)(base + sizeof(int)),
           (unsigned long long)(base + 2 * sizeof(int)));

    printf("double* : %llu, %llu, %llu\n",
           (unsigned long long)base,
           (unsigned long long)(base + sizeof(double)),
           (unsigned long long)(base + 2 * sizeof(double)));

    return 0;
}
